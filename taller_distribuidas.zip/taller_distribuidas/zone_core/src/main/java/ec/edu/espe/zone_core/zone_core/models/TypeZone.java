package ec.edu.espe.zone_core.zone_core.models;

public enum TypeZone {
    VIP, EXTERNAL, TERMINAL
}
