package ec.edu.espe.zone_core.zone_core.models;

public enum SpaceStatus {
    AVAILABLE, OCCUPIED, MAINTENANCE, RESERVED
}
